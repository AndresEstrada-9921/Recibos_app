import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:recibos_app/main.dart';

void main() {
  testWidgets('RecibosApp smoke test', (WidgetTester tester) async {
    // Build our app and trigger a frame.
    await tester.pumpWidget(const RecibosApp());

    // Verify that the app title is present
    expect(find.text('📱 Recibos App'), findsOneWidget);

    // Verify that the buttons are present
    expect(find.text('Seleccionar Recibo'), findsOneWidget);
    expect(find.text('Agregar Consignaciones'), findsOneWidget);
    expect(find.text('Generar Montaje'), findsOneWidget);

    // Verify that initially no images are shown
    expect(find.text('📄 Recibo Principal'), findsNothing);
    expect(find.text('🧾 Consignaciones (0)'), findsNothing);
  });
}