import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';

import 'services/montaje_service.dart';
import 'screens/recibos_anteriores_screen.dart';
import 'screens/configuracion_screen.dart';

void main() {
  runApp(const RecibosApp());
}

class RecibosApp extends StatelessWidget {
  const RecibosApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Recibos',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF1976D2),
          brightness: Brightness.light,
        ),
        appBarTheme: const AppBarTheme(
          centerTitle: true,
          elevation: 0,
        ),
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  File? recibo;
  final List<File> consignaciones = [];
  bool isGenerating = false;

  @override
  void initState() {
    super.initState();
    _crearCarpetaRecibos();
  }

  // Crear carpeta Recibos en el almacenamiento
  Future<void> _crearCarpetaRecibos() async {
    try {
      final directory = await getExternalStorageDirectory();
      if (directory != null) {
        final recibosDir = Directory('${directory.path}/Recibos');
        if (!await recibosDir.exists()) {
          await recibosDir.create(recursive: true);
        }
      }
    } catch (e) {
      debugPrint('Error al crear carpeta: $e');
    }
  }

  // Seleccionar recibo
  Future<void> seleccionarRecibo() async {
    try {
      final picker = ImagePicker();
      final XFile? img = await picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 100,
      );

      if (img != null) {
        setState(() => recibo = File(img.path));
      }
    } catch (e) {
      if (mounted) {
        _mostrarError("Error al seleccionar recibo: $e");
      }
    }
  }

  // Seleccionar consignaciones
  Future<void> seleccionarConsignaciones() async {
    try {
      final picker = ImagePicker();
      final List<XFile> imgs = await picker.pickMultiImage(imageQuality: 100);

      if (imgs.isNotEmpty) {
        setState(() {
          consignaciones.addAll(imgs.map((e) => File(e.path)));
        });
      }
    } catch (e) {
      if (mounted) {
        _mostrarError("Error al seleccionar consignaciones: $e");
      }
    }
  }

  // Eliminar una consignación
  void eliminarConsignacion(int index) {
    setState(() {
      consignaciones.removeAt(index);
    });
  }

  // Generar montaje final
  Future<void> generarMontaje() async {
    if (recibo == null) {
      _mostrarAdvertencia("Selecciona un recibo primero");
      return;
    }

    if (consignaciones.isEmpty) {
      _mostrarAdvertencia("Agrega al menos una consignación");
      return;
    }

    setState(() => isGenerating = true);

    try {
      final montajeService = MontajeService();
      final archivo = await montajeService.generarMontaje(
        recibo: recibo!,
        consignaciones: consignaciones,
      );

      setState(() => isGenerating = false);

      if (mounted) {
        // Navegar sin limpiar los datos
        final resultado = await Navigator.push<bool>(
          context,
          MaterialPageRoute(
            builder: (_) => ResultadoScreen(imagen: archivo),
          ),
        );

        // Solo limpiar si el usuario finalizó o compartió
        if (resultado == true && mounted) {
          setState(() {
            recibo = null;
            consignaciones.clear();
          });
        }
      }
    } catch (e) {
      setState(() => isGenerating = false);
      if (mounted) {
        _mostrarError("Error al generar montaje: $e");
      }
    }
  }

  void _mostrarError(String mensaje) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(mensaje),
        backgroundColor: Colors.red.shade700,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void _mostrarAdvertencia(String mensaje) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(mensaje),
        backgroundColor: Colors.orange.shade700,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Aquí irá el logo (por ahora un ícono placeholder)
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Icon(Icons.receipt_long, color: Color(0xFF1976D2)),
            ),
            const SizedBox(width: 12),
            const Text(
              'Recibos',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
          ],
        ),
        backgroundColor: Theme.of(context).colorScheme.primary,
        foregroundColor: Colors.white,
      ),
      drawer: _buildDrawer(),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Título de la sección
            const Text(
              'Crear nuevo montaje',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Selecciona un recibo y las consignaciones para crear el montaje',
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey.shade600,
              ),
            ),
            const SizedBox(height: 24),

            // Botón seleccionar recibo
            _buildBotonPrincipal(
              icono: Icons.receipt_long,
              texto: "Seleccionar Recibo",
              color: Colors.blue.shade700,
              onPressed: isGenerating ? null : seleccionarRecibo,
            ),
            const SizedBox(height: 16),

            // Botón seleccionar consignaciones
            _buildBotonPrincipal(
              icono: Icons.add_photo_alternate,
              texto: "Agregar Consignaciones",
              color: Colors.green.shade700,
              onPressed: isGenerating ? null : seleccionarConsignaciones,
            ),
            const SizedBox(height: 16),

            // Botón generar montaje
            _buildBotonPrincipal(
              icono: isGenerating ? null : Icons.auto_awesome,
              texto: isGenerating ? "Generando..." : "Generar Montaje",
              color: Colors.orange.shade700,
              onPressed: isGenerating ? null : generarMontaje,
              isLoading: isGenerating,
            ),
            const SizedBox(height: 32),

            // Vista previa del recibo
            if (recibo != null) _buildReciboPreview(),

            // Vista previa de consignaciones
            if (consignaciones.isNotEmpty) ...[
              const SizedBox(height: 20),
              _buildConsignacionesPreview(),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildDrawer() {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          DrawerHeader(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Theme.of(context).colorScheme.primary,
                  Theme.of(context).colorScheme.primaryContainer,
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Container(
                  width: 64,
                  height: 64,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: const Icon(
                    Icons.receipt_long,
                    size: 40,
                    color: Color(0xFF1976D2),
                  ),
                ),
                const SizedBox(height: 12),
                const Text(
                  'Recibos',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  'Gestiona tus recibos',
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.8),
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          ),
          ListTile(
            leading: const Icon(Icons.history),
            title: const Text('Recibos Anteriores'),
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const RecibosAnterioresScreen(),
                ),
              );
            },
          ),
          ListTile(
            leading: const Icon(Icons.settings),
            title: const Text('Configuración'),
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const ConfiguracionScreen(),
                ),
              );
            },
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.info_outline),
            title: const Text('Acerca de'),
            onTap: () {
              Navigator.pop(context);
              _mostrarAcercaDe();
            },
          ),
        ],
      ),
    );
  }

  Widget _buildBotonPrincipal({
    IconData? icono,
    required String texto,
    required Color color,
    required VoidCallback? onPressed,
    bool isLoading = false,
  }) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
        backgroundColor: color,
        foregroundColor: Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        elevation: 2,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          if (isLoading)
            const SizedBox(
              width: 20,
              height: 20,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                color: Colors.white,
              ),
            )
          else if (icono != null)
            Icon(icono, size: 24),
          const SizedBox(width: 12),
          Text(
            texto,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildReciboPreview() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Row(
                  children: [
                    Icon(Icons.receipt_long, color: Colors.blue),
                    SizedBox(width: 8),
                    Text(
                      'Recibo Principal',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                IconButton(
                  icon: const Icon(Icons.close, color: Colors.red),
                  onPressed: () => setState(() => recibo = null),
                ),
              ],
            ),
            const SizedBox(height: 12),
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.file(
                recibo!,
                width: double.infinity,
                fit: BoxFit.cover,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildConsignacionesPreview() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.image, color: Colors.green),
                const SizedBox(width: 8),
                Text(
                  'Consignaciones (${consignaciones.length})',
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            SizedBox(
              height: 140,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: consignaciones.length,
                itemBuilder: (context, index) {
                  return Padding(
                    padding: const EdgeInsets.only(right: 12),
                    child: Stack(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(12),
                          child: Image.file(
                            consignaciones[index],
                            width: 100,
                            height: 140,
                            fit: BoxFit.cover,
                          ),
                        ),
                        Positioned(
                          top: 4,
                          right: 4,
                          child: InkWell(
                            onTap: () => eliminarConsignacion(index),
                            child: Container(
                              padding: const EdgeInsets.all(4),
                              decoration: const BoxDecoration(
                                color: Colors.red,
                                shape: BoxShape.circle,
                              ),
                              child: const Icon(
                                Icons.close,
                                size: 16,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _mostrarAcercaDe() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Acerca de Recibos'),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Versión: 1.0.0'),
            SizedBox(height: 8),
            Text('Aplicación para crear montajes de recibos con consignaciones.'),
            SizedBox(height: 8),
            Text('Desarrollado con Flutter'),
            SizedBox(height: 12),
            Divider(),
            SizedBox(height: 8),
            Text(
              'Creado por:',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 4),
            Text('Andrés Herrera'),
            Text(
              'andresyessidherrera@gmail.com',
              style: TextStyle(fontSize: 12, color: Colors.blue),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cerrar'),
          ),
        ],
      ),
    );
  }
}

/// Pantalla de resultado final
class ResultadoScreen extends StatelessWidget {
  final File imagen;

  const ResultadoScreen({required this.imagen, super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Montaje Generado'),
        backgroundColor: Theme.of(context).colorScheme.primary,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.share),
            onPressed: () async {
              await _compartir(context);
              if (context.mounted) {
                Navigator.pop(context, true); // Retornar true para limpiar
              }
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: InteractiveViewer(
              minScale: 0.5,
              maxScale: 4.0,
              child: Center(
                child: Image.file(
                  imagen,
                  fit: BoxFit.contain,
                ),
              ),
            ),
          ),
          Container(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () async {
                      await _compartir(context);
                      if (context.mounted) {
                        Navigator.pop(context, true); // Retornar true para limpiar
                      }
                    },
                    icon: const Icon(Icons.share),
                    label: const Text('Compartir'),
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.all(16),
                      backgroundColor: Colors.green.shade700,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () => Navigator.pop(context, true), // Retornar true para limpiar
                    icon: const Icon(Icons.check),
                    label: const Text('Finalizar'),
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.all(16),
                      backgroundColor: Colors.blue.shade700,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _compartir(BuildContext context) async {
    try {
      await Share.shareXFiles([XFile(imagen.path)]);
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error al compartir: $e')),
        );
      }
    }
  }
}