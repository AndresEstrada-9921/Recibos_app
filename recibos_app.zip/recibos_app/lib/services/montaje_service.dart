import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image/image.dart' as img;
import 'package:palette_generator/palette_generator.dart';
import 'package:path_provider/path_provider.dart';

class MontajeService {
  /// Obtener color dominante del recibo
  Future<Color> obtenerColorDominante(File recibo) async {
    try {
      final palette = await PaletteGenerator.fromImageProvider(
        FileImage(recibo),
        maximumColorCount: 20,
      );

      Color colorFinal = palette.dominantColor?.color ??
          palette.vibrantColor?.color ??
          palette.lightVibrantColor?.color ??
          const Color(0xFFE8E8E8);

      return colorFinal;
    } catch (e) {
      debugPrint("Error al obtener color dominante: $e");
      return const Color(0xFFE8E8E8);
    }
  }

  /// Generar montaje con recibo y consignaciones
  Future<File> generarMontaje({
    required File recibo,
    required List<File> consignaciones,
  }) async {
    try {
      // Leer imagen del recibo
      final bytesRecibo = await recibo.readAsBytes();
      final imgRecibo = img.decodeImage(bytesRecibo);

      if (imgRecibo == null) {
        throw Exception("No se pudo decodificar la imagen del recibo");
      }

      final reciboWidth = imgRecibo.width;
      final reciboHeight = imgRecibo.height;

      // Tamaño estándar para consignaciones (25% del ancho para que quepan 4)
      final int anchoConsignacion = (reciboWidth * 0.25).toInt();
      // Altura fija para todas las consignaciones
      final int altoConsignacion = (anchoConsignacion * 1.4).toInt();

      // Procesar consignaciones: TODAS del mismo tamaño
      final List<img.Image> imgsConsig = [];

      for (final file in consignaciones) {
        try {
          final bytes = await file.readAsBytes();
          final decoded = img.decodeImage(bytes);

          if (decoded != null) {
            // Redimensionar a tamaño FIJO (mismo ancho y alto para todas)
            final resized = img.copyResize(
              decoded,
              width: anchoConsignacion,
              height: altoConsignacion,
              interpolation: img.Interpolation.linear,
            );
            imgsConsig.add(resized);
          }
        } catch (e) {
          debugPrint("Error al procesar consignación: $e");
        }
      }

      if (imgsConsig.isEmpty) {
        throw Exception("No se pudo procesar ninguna consignación");
      }

      // Organizar en filas (4 por fila)
      final List<List<img.Image>> filas = [];
      for (int i = 0; i < imgsConsig.length; i += 4) {
        final end = (i + 4 < imgsConsig.length) ? i + 4 : imgsConsig.length;
        filas.add(imgsConsig.sublist(i, end));
      }

      // Espaciado
      const int espacioEntreConsignaciones = 8;
      const int espacioEntreFilas = 8;

      // Calcular dimensiones finales
      // Las consignaciones empiezan al 85% del recibo
      final int offsetInicioConsignaciones = (reciboHeight * 0.85).toInt();

      // Calcular altura total de consignaciones
      int alturaConsignaciones = filas.length * altoConsignacion;
      if (filas.length > 1) {
        alturaConsignaciones += (filas.length - 1) * espacioEntreFilas;
      }

      // Altura total del canvas
      final int totalHeight = offsetInicioConsignaciones + alturaConsignaciones + 15;

      // Ancho máximo
      int maxWidth = reciboWidth;

      // Obtener color dominante
      final Color colorDominante = await obtenerColorDominante(recibo);

      // Crear canvas
      final montage = img.Image(
        width: maxWidth,
        height: totalHeight,
        numChannels: 4,
      );

      // Pintar fondo
      img.fill(
        montage,
        color: img.ColorRgb8(
          colorDominante.red,
          colorDominante.green,
          colorDominante.blue,
        ),
      );

      // Pegar recibo centrado arriba
      final int reciboX = (maxWidth - reciboWidth) ~/ 2;
      img.compositeImage(
        montage,
        imgRecibo,
        dstX: reciboX,
        dstY: 0,
      );

      // Pegar consignaciones en filas
      int offsetY = offsetInicioConsignaciones;

      for (final fila in filas) {
        // Calcular ancho total de la fila
        final int anchoFila = fila.length * anchoConsignacion +
            (fila.length - 1) * espacioEntreConsignaciones;

        // Centrar fila horizontalmente
        int offsetX = (maxWidth - anchoFila) ~/ 2;

        // Pegar cada consignación
        for (final consig in fila) {
          img.compositeImage(
            montage,
            consig,
            dstX: offsetX,
            dstY: offsetY,
          );
          offsetX += anchoConsignacion + espacioEntreConsignaciones;
        }

        // Avanzar a siguiente fila
        offsetY += altoConsignacion + espacioEntreFilas;
      }

      // Codificar a PNG
      final Uint8List pngBytes = Uint8List.fromList(
        img.encodePng(montage, level: 6),
      );

      // Guardar en carpeta Recibos dentro de Pictures
      // Esta ruta es accesible desde la galería del dispositivo
      String rutaBase;

      if (Platform.isAndroid) {
        // Para Android: /storage/emulated/0/Pictures/Recibos
        final directory = Directory('/storage/emulated/0/Pictures/Recibos');

        if (!await directory.exists()) {
          await directory.create(recursive: true);
        }
        rutaBase = directory.path;
      } else {
        // Para iOS u otros
        final directory = await getApplicationDocumentsDirectory();
        final recibosDir = Directory('${directory.path}/Recibos');

        if (!await recibosDir.exists()) {
          await recibosDir.create(recursive: true);
        }
        rutaBase = recibosDir.path;
      }

      final timestamp = DateTime.now().millisecondsSinceEpoch;
      final output = File('$rutaBase/recibo_$timestamp.png');

      await output.writeAsBytes(pngBytes);

      return output;
    } catch (e) {
      throw Exception("Error al generar montaje: $e");
    }
  }
}
