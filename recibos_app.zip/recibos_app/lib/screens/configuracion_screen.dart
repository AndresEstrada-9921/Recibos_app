import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ConfiguracionScreen extends StatefulWidget {
  const ConfiguracionScreen({super.key});

  @override
  State<ConfiguracionScreen> createState() => _ConfiguracionScreenState();
}

class _ConfiguracionScreenState extends State<ConfiguracionScreen> {
  bool autoGuardar = true;
  bool comprimirImagenes = false;
  int calidadImagen = 100;
  String formatoGuardado = 'PNG';
  String ubicacionGuardado = '/storage/emulated/0/Pictures/Recibos';

  @override
  void initState() {
    super.initState();
    _cargarConfiguracion();
  }

  Future<void> _cargarConfiguracion() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      autoGuardar = prefs.getBool('autoGuardar') ?? true;
      comprimirImagenes = prefs.getBool('comprimirImagenes') ?? false;
      calidadImagen = prefs.getInt('calidadImagen') ?? 100;
      formatoGuardado = prefs.getString('formatoGuardado') ?? 'PNG';
      ubicacionGuardado = prefs.getString('ubicacionGuardado') ??
          '/storage/emulated/0/Pictures/Recibos';
    });
  }

  Future<void> _guardarConfiguracion() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('autoGuardar', autoGuardar);
    await prefs.setBool('comprimirImagenes', comprimirImagenes);
    await prefs.setInt('calidadImagen', calidadImagen);
    await prefs.setString('formatoGuardado', formatoGuardado);
    await prefs.setString('ubicacionGuardado', ubicacionGuardado);

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Configuración guardada'),
          backgroundColor: Colors.green,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Configuración'),
        backgroundColor: Theme.of(context).colorScheme.primary,
        foregroundColor: Colors.white,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildSeccion(
            titulo: 'General',
            children: [
              SwitchListTile(
                title: const Text('Auto-guardar montajes'),
                subtitle: const Text('Guardar automáticamente en Recibos'),
                value: autoGuardar,
                onChanged: (value) {
                  setState(() => autoGuardar = value);
                  _guardarConfiguracion();
                },
              ),
            ],
          ),
          const SizedBox(height: 24),
          _buildSeccion(
            titulo: 'Calidad de Imagen',
            children: [
              SwitchListTile(
                title: const Text('Comprimir imágenes'),
                subtitle: const Text('Reduce el tamaño de archivo'),
                value: comprimirImagenes,
                onChanged: (value) {
                  setState(() => comprimirImagenes = value);
                  _guardarConfiguracion();
                },
              ),
              ListTile(
                title: const Text('Calidad de imagen'),
                subtitle: Text('${calidadImagen}%'),
                trailing: SizedBox(
                  width: 200,
                  child: Slider(
                    value: calidadImagen.toDouble(),
                    min: 50,
                    max: 100,
                    divisions: 10,
                    label: '$calidadImagen%',
                    onChanged: (value) {
                      setState(() => calidadImagen = value.toInt());
                    },
                    onChangeEnd: (value) => _guardarConfiguracion(),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          _buildSeccion(
            titulo: 'Formato de Guardado',
            children: [
              RadioListTile<String>(
                title: const Text('PNG (Mejor calidad)'),
                subtitle: const Text('Recomendado para recibos'),
                value: 'PNG',
                groupValue: formatoGuardado,
                onChanged: (value) {
                  setState(() => formatoGuardado = value!);
                  _guardarConfiguracion();
                },
              ),
              RadioListTile<String>(
                title: const Text('JPG (Menor tamaño)'),
                subtitle: const Text('Archivos más pequeños'),
                value: 'JPG',
                groupValue: formatoGuardado,
                onChanged: (value) {
                  setState(() => formatoGuardado = value!);
                  _guardarConfiguracion();
                },
              ),
            ],
          ),
          const SizedBox(height: 24),
          _buildSeccion(
            titulo: 'Almacenamiento',
            children: [
              ListTile(
                leading: const Icon(Icons.folder),
                title: const Text('Ubicación de guardado'),
                subtitle: Text(
                  ubicacionGuardado,
                  style: const TextStyle(fontSize: 12),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                trailing: const Icon(Icons.edit),
                onTap: () {
                  _cambiarUbicacion();
                },
              ),
              ListTile(
                leading: const Icon(Icons.delete_outline),
                title: const Text('Limpiar caché'),
                subtitle: const Text('Eliminar archivos temporales'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () {
                  _limpiarCache();
                },
              ),
            ],
          ),
          const SizedBox(height: 24),
          _buildSeccion(
            titulo: 'Acerca de',
            children: [
              const ListTile(
                leading: Icon(Icons.info_outline),
                title: Text('Versión'),
                subtitle: Text('1.0.0'),
              ),
              ListTile(
                leading: const Icon(Icons.code),
                title: const Text('Desarrollado por'),
                subtitle: const Text('Andrés Herrera\nandresyessidherrera@gmail.com'),
                isThreeLine: true,
                trailing: const Icon(Icons.chevron_right),
                onTap: () {
                  _mostrarAcercaDe();
                },
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSeccion({
    required String titulo,
    required List<Widget> children,
  }) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text(
              titulo,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Theme.of(context).colorScheme.primary,
              ),
            ),
          ),
          const Divider(height: 1),
          ...children,
        ],
      ),
    );
  }

  void _cambiarUbicacion() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Cambiar ubicación'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              title: const Text('Pictures/Recibos'),
              subtitle: const Text('Recomendado - Visible en galería'),
              leading: const Icon(Icons.photo_library),
              selected: ubicacionGuardado == '/storage/emulated/0/Pictures/Recibos',
              onTap: () {
                setState(() {
                  ubicacionGuardado = '/storage/emulated/0/Pictures/Recibos';
                });
                _guardarConfiguracion();
                Navigator.pop(context);
              },
            ),
            ListTile(
              title: const Text('Documents/Recibos'),
              subtitle: const Text('Documentos del dispositivo'),
              leading: const Icon(Icons.folder),
              selected: ubicacionGuardado == '/storage/emulated/0/Documents/Recibos',
              onTap: () {
                setState(() {
                  ubicacionGuardado = '/storage/emulated/0/Documents/Recibos';
                });
                _guardarConfiguracion();
                Navigator.pop(context);
              },
            ),
            ListTile(
              title: const Text('Download/Recibos'),
              subtitle: const Text('Carpeta de descargas'),
              leading: const Icon(Icons.download),
              selected: ubicacionGuardado == '/storage/emulated/0/Download/Recibos',
              onTap: () {
                setState(() {
                  ubicacionGuardado = '/storage/emulated/0/Download/Recibos';
                });
                _guardarConfiguracion();
                Navigator.pop(context);
              },
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancelar'),
          ),
        ],
      ),
    );
  }

  void _limpiarCache() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Limpiar caché'),
        content: const Text(
          '¿Deseas eliminar los archivos temporales? Esto no afectará tus recibos guardados.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancelar'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Caché limpiado correctamente'),
                  backgroundColor: Colors.green,
                ),
              );
            },
            child: const Text('Limpiar'),
          ),
        ],
      ),
    );
  }

  void _mostrarAcercaDe() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Acerca de Recibos'),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Versión: 1.0.0'),
            SizedBox(height: 12),
            Text(
              'Aplicación diseñada para crear montajes profesionales de recibos con consignaciones.',
            ),
            SizedBox(height: 12),
            Text('Desarrollado con Flutter'),
            SizedBox(height: 12),
            Divider(),
            SizedBox(height: 8),
            Text(
              'Creado por:',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 4),
            Text('Andrés Herrera'),
            Text(
              'andresyessidherrera@gmail.com',
              style: TextStyle(fontSize: 12, color: Colors.blue),
            ),
            SizedBox(height: 12),
            Text('© 2025 Recibos App'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cerrar'),
          ),
        ],
      ),
    );
  }
}