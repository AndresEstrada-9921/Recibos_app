import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:image_picker/image_picker.dart';

class RecibosAnterioresScreen extends StatefulWidget {
  const RecibosAnterioresScreen({super.key});

  @override
  State<RecibosAnterioresScreen> createState() =>
      _RecibosAnterioresScreenState();
}

class _RecibosAnterioresScreenState extends State<RecibosAnterioresScreen> {
  List<File> recibosGuardados = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _cargarRecibos();
  }

  Future<void> _cargarRecibos() async {
    try {
      Directory? recibosDir;

      if (Platform.isAndroid) {
        // Buscar en Pictures/Recibos
        recibosDir = Directory('/storage/emulated/0/Pictures/Recibos');
      } else {
        final directory = await getApplicationDocumentsDirectory();
        recibosDir = Directory('${directory.path}/Recibos');
      }

      if (await recibosDir.exists()) {
        final files = recibosDir
            .listSync()
            .where((item) => item is File && item.path.endsWith('.png'))
            .map((item) => item as File)
            .toList();

        // Ordenar por fecha de modificación (más reciente primero)
        files.sort((a, b) =>
            b.lastModifiedSync().compareTo(a.lastModifiedSync()));

        setState(() {
          recibosGuardados = files;
          isLoading = false;
        });
      } else {
        setState(() => isLoading = false);
      }
    } catch (e) {
      setState(() => isLoading = false);
      debugPrint('Error al cargar recibos: $e');
    }
  }

  Future<void> _eliminarRecibo(File archivo) async {
    final confirmar = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Eliminar recibo'),
        content: const Text('¿Estás seguro de eliminar este recibo?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancelar'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Eliminar'),
          ),
        ],
      ),
    );

    if (confirmar == true) {
      try {
        await archivo.delete();
        _cargarRecibos();
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Recibo eliminado')),
          );
        }
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Error al eliminar: $e')),
          );
        }
      }
    }
  }

  Future<void> _compartirRecibo(File archivo) async {
    try {
      await Share.shareXFiles([XFile(archivo.path)]);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error al compartir: $e')),
        );
      }
    }
  }

  void _verDetalles(File archivo) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => DetalleReciboScreen(archivo: archivo),
      ),
    ).then((_) => _cargarRecibos());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Recibos Anteriores'),
        backgroundColor: Theme.of(context).colorScheme.primary,
        foregroundColor: Colors.white,
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : recibosGuardados.isEmpty
          ? _buildEmptyState()
          : _buildListaRecibos(),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.folder_open,
            size: 80,
            color: Colors.grey.shade400,
          ),
          const SizedBox(height: 16),
          Text(
            'No hay recibos guardados',
            style: TextStyle(
              fontSize: 18,
              color: Colors.grey.shade600,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Crea tu primer montaje para verlo aquí',
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey.shade500,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildListaRecibos() {
    return RefreshIndicator(
      onRefresh: _cargarRecibos,
      child: GridView.builder(
        padding: const EdgeInsets.all(16),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          childAspectRatio: 0.75,
        ),
        itemCount: recibosGuardados.length,
        itemBuilder: (context, index) {
          final archivo = recibosGuardados[index];
          return _buildReciboCard(archivo);
        },
      ),
    );
  }

  Widget _buildReciboCard(File archivo) {
    final fecha = archivo.lastModifiedSync();
    final fechaTexto =
        '${fecha.day}/${fecha.month}/${fecha.year} ${fecha.hour}:${fecha.minute.toString().padLeft(2, '0')}';

    return Card(
      elevation: 3,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: InkWell(
        onTap: () => _verDetalles(archivo),
        borderRadius: BorderRadius.circular(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Expanded(
              child: ClipRRect(
                borderRadius:
                const BorderRadius.vertical(top: Radius.circular(12)),
                child: Image.file(
                  archivo,
                  fit: BoxFit.cover,
                ),
              ),
            ),
            Container(
              padding: const EdgeInsets.all(8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    fechaTexto,
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.share, size: 20),
                        onPressed: () => _compartirRecibo(archivo),
                        color: Colors.blue,
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete, size: 20),
                        onPressed: () => _eliminarRecibo(archivo),
                        color: Colors.red,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class DetalleReciboScreen extends StatelessWidget {
  final File archivo;

  const DetalleReciboScreen({required this.archivo, super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Detalle del Recibo'),
        backgroundColor: Theme.of(context).colorScheme.primary,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.share),
            onPressed: () async {
              await Share.shareXFiles([XFile(archivo.path)]);
            },
          ),
        ],
      ),
      body: InteractiveViewer(
        minScale: 0.5,
        maxScale: 4.0,
        child: Center(
          child: Image.file(archivo),
        ),
      ),
    );
  }
}